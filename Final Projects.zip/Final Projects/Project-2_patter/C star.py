a=""
for row in range(0,7):
    for col in range(0,5):
        if (col==0 or (row==0 or row==6) and (col>0)):
         a=a+"*"    
        else:      
            a=a+" "    
    a=a+"\n"    
print(a);
