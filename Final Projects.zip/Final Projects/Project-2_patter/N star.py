a=""
for row in range(0,6):
    for col in range(0,6):
        if col==0 or col==5 or (row==col and (col>0 and col<5)):
         a=a+"*"    
        else:      
            a=a+" "    
    a=a+"\n"    
print(a);
