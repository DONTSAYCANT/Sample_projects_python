a=""
for row in range(0,7):
    for col in range(0,7):
        if col==0 or (col==4 and (row==1 or row==2)) or ((row==0 or row==3) and (col>0 and col<4)):
         a=a+"*"    
        else:      
            a=a+" "    
    a=a+"\n"    
print(a);
