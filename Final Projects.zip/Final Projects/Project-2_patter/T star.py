a=""
for row in range(0,7):
    for col in range(0,7):
        if col==2 or (row==0 and col!=2):
         a=a+"*"    
        else:      
            a=a+" "    
    a=a+"\n"    
print(a);
