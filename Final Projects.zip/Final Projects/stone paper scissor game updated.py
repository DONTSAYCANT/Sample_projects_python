import random
import sys

L = ['Stone','Paper','Scissors']
n = input('How many time u want to play? ')

try:
    n = int(n)
except Exception as e:
    print('Invalid input.  %s' % e)
    sys.exit()	

sys_count = 0
usr_count = 0
eql_count = 0

print('Stone--0, paper--1, Scissor--2')
for i in range(n):
   usr = input('\nEnter ur choice 0,1,2: ')
   if (usr != '0' and usr != '1' and usr !='2'):
       print('Invalid input %s' % usr)
       sys.exit()	   
   usr = L[int(usr)]
   system = random.choice(L)
   print('System chose',system) 
   if system == usr:
       print('Both are equal')
       eql_count += 1	   
   elif system=='Stone' and usr=='Paper':
       print('User wins')
       usr_count += 1	   
   elif system=='Stone' and usr=='Scissors':
       print('System wins')
       sys_count += 1	   
   elif system=='Paper' and usr=='Stone':
       print('System wins')
       sys_count += 1	   
   elif system=='Paper' and usr=='Scissors':
       print('User wins')
       usr_count += 1	   
   elif system=='Scissors' and usr=='Stone':
       print('User wins')
       usr_count += 1	   
   elif system=='Scissors' and usr=='Paper':
       print('System wins')
       sys_count += 1
print('\nUser won: ',usr_count)	   
print('System won: ',sys_count)
print('Equal count: ',eql_count)
print('Total played: ',(eql_count+sys_count+usr_count))
